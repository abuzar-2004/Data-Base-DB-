//#include <iostream>
//#include <fstream>
//#include <string>
//#include <limits>
//using namespace std;
//
//struct Employee 
//{
//    string empID;
//    string empName;
//    string empJoiningDate;
//    string contact;
//    double salary;
//    string maritalStatus;
//};
//
//void findHighestSalaryEmployee(Employee employees[], int size) 
//{
//    double highestSalary = 0;
//    string highestSalaryEmployee;
//    for (int i = 0; i < size; ++i) 
//    {
//        if (employees[i].salary > highestSalary) 
//        {
//            highestSalary = employees[i].salary;
//            highestSalaryEmployee = employees[i].empName;
//        }
//    }
//    cout << "Employee with the highest salary: " << highestSalaryEmployee << endl;
//}
//
//void findLowestSalaryEmployee(Employee employees[], int size) 
//{
//    double lowestSalary = numeric_limits<double>::max();
//    string lowestSalaryEmployee;
//    for (int i = 0; i < size; ++i) {
//        if (employees[i].salary < lowestSalary)
//        {
//            lowestSalary = employees[i].salary;
//            lowestSalaryEmployee = employees[i].empName;
//        }
//    }
//    cout << "Employee with the lowest salary: " << lowestSalaryEmployee << endl;
//}
//
//void countMarriedEmployees(Employee employees[], int size)
//{
//    int marriedCount = 0;
//    for (int i = 0; i < size; ++i) 
//    {
//        if (employees[i].maritalStatus == "Married")
//        {
//            marriedCount++;
//        }
//    }
//    cout << "Total number of married employees: " << marriedCount << endl;
//}
//
//void displaySingleEmployees(Employee employees[], int size) 
//{
//    cout << "Employees who are single: " << endl;
//    for (int i = 0; i < size; ++i) 
//    {
//        if (employees[i].maritalStatus == "Single") 
//        {
//            cout << employees[i].empName << endl;
//        }
//    }
//}
//
//void printAverageSalary(Employee employees[], int size) 
//{
//    double totalSalary = 0;
//    for (int i = 0; i < size; ++i) 
//    {
//        totalSalary += employees[i].salary;
//    }
//    double averageSalary = totalSalary / size;
//    cout << "Average salary of all employees: " << averageSalary << endl;
//}
//
//void displayEmployeesSalaryGreaterThanImran(Employee employees[], int size) 
//{
//    double imranSalary = 78000; 
//    cout << "Employees with salary greater than Imran's:" << endl;
//    for (int i = 0; i < size; ++i) 
//    {
//        if (employees[i].salary > imranSalary)
//        {
//            cout << employees[i].empName << endl;
//        }
//    }
//}
//
//void displayEmployeesSalaryLessThanAziz(Employee employees[], int size)
//{
//    double azizSalary = 74000;  
//    cout << "Employees with salary less than Aziz's:" << endl;
//    for (int i = 0; i < size; ++i) 
//    {
//        if (employees[i].salary < azizSalary) 
//        {
//            cout << employees[i].empName << endl;
//        }
//    }
//}
//
//void searchEmployee(Employee employees[], int size, const string& name) 
//{
//    for (int i = 0; i < size; ++i) 
//    {
//        if (employees[i].empName == name)
//        {
//            cout << "Employee Information for " << name << ":" << endl;
//            cout << "EmpID: " << employees[i].empID << ", Name: " << employees[i].empName
//                << ", Joining Date: " << employees[i].empJoiningDate << ", Contact: " << employees[i].contact
//                << ", Salary: " << employees[i].salary << ", Marital Status: " << employees[i].maritalStatus << endl;
//            return;
//        }
//    }
//    cout << "Employee " << name << " not found." << endl;
//}
//
//int main()
//{
//    ifstream empFile("employee.csv");
//    if (!empFile)
//    {
//        cout << "Error opening employee file!" << endl;
//        return 1;
//    }
//
//    const int maxEmployees = 100;
//    Employee employees[maxEmployees];
//    string line;
//    int employeeCount = 0;
//
//    getline(empFile, line);  
//
//    while (getline(empFile, line) && employeeCount < maxEmployees) {
//        Employee emp;
//        size_t commaPos = line.find(',');
//        emp.empID = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.empName = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.empJoiningDate = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.contact = line.substr(0, commaPos);
//        line = line.substr(commaPos + 1);
//
//        commaPos = line.find(',');
//        emp.salary = stod(line.substr(0, commaPos));
//        line = line.substr(commaPos + 1);
//
//        emp.maritalStatus = line;
//
//        employees[employeeCount] = emp;
//        employeeCount++;
//    }
//
//    empFile.close();
//
//    findHighestSalaryEmployee(employees, employeeCount);
//    findLowestSalaryEmployee(employees, employeeCount);
//    countMarriedEmployees(employees, employeeCount);
//    displaySingleEmployees(employees, employeeCount);
//    printAverageSalary(employees, employeeCount);
//    displayEmployeesSalaryGreaterThanImran(employees, employeeCount);
//    displayEmployeesSalaryLessThanAziz(employees, employeeCount);
//    searchEmployee(employees, employeeCount, "Omer");
//
//    return 0;
//}

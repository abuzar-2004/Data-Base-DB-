//#include <iostream>
//#include <fstream>
//#include <string>
//using namespace std;
//
//struct Student 
//{
//    string registrationNumber;
//    string firstName;
//    string lastName;
//    string program;
//    double cgpa;
//    string contactNumber;
//};
//
//int main()
//{
//    ofstream outFile("StudentInfo.csv");
//
//    if (!outFile) 
//    {
//        cout << "Error opening file!" << endl;
//        return 1;
//    }
//
//    
//    outFile << "RegistrationNumber, FirstName, LastName, Program, CGPA, ContactNumber\n";
//
//    int numberOfStudents;
//    cout << "Enter number of students: ";
//    cin >> numberOfStudents;
//
//    
//    for (int i = 0; i < numberOfStudents; i++)
//    {
//        Student student;
//
//       
//        cout << "Enter details for student " << i + 1 << ":" << endl;
//
//        cout << "Registration Number: ";
//        cin >> student.registrationNumber;
//
//        cout << "First Name: ";
//        cin >> student.firstName;
//
//        cout << "Last Name: ";
//        cin >> student.lastName;
//
//        cout << "Program: ";
//        cin >> student.program;
//
//        cout << "CGPA: ";
//        cin >> student.cgpa;
//
//        cout << "Contact Number: ";
//        cin >> student.contactNumber;
//
//       
//        outFile << student.registrationNumber << ", "
//            << student.firstName << ", "
//            << student.lastName << ", "
//            << student.program << ", "
//            << student.cgpa << ", "
//            << student.contactNumber << "\n";
//    }
//
//    
//    outFile.close();
//    cout << "Student information has been written to StudentInfo.csv" << endl;
//
//    return 0;
//}

//#include <iostream>
//#include <fstream>
//#include <string>
//using namespace std;
//
//const int MAX_STUDENTS = 100;
//const int MAX_LENGTH = 100;    
//
//
//struct Student
//{
//    string regNumber;
//    string name;
//    string program;
//    float cgpa;
//    string phoneNumber;
//};
//
//
//int readCSVFile(const string& filename, Student students[]) 
//{
//    ifstream file(filename);
//
//   
//    if (!file.is_open()) 
//    {
//        cerr << "Error opening the file!" << endl;
//        return 0;
//    }
//
//    int count = 0;
//    string line;
//    while (getline(file, line) && count < MAX_STUDENTS)
//    {
//        size_t startPos = 0, endPos = line.find(',');
//        students[count].regNumber = line.substr(startPos, endPos - startPos);
//
//        startPos = endPos + 1;
//        endPos = line.find(',', startPos);
//        students[count].name = line.substr(startPos, endPos - startPos);
//
//        startPos = endPos + 1;
//        endPos = line.find(',', startPos);
//        students[count].program = line.substr(startPos, endPos - startPos);
//
//        startPos = endPos + 1;
//        endPos = line.find(',', startPos);
//        students[count].cgpa = stof(line.substr(startPos, endPos - startPos));
//
//        startPos = endPos + 1;
//        students[count].phoneNumber = line.substr(startPos);
//
//        count++;
//    }
//
//    file.close();
//    return count;
//}
//
//
//void searchStudentByRegNumber(const Student students[], int numStudents, const string& regNumber) 
//{
//    for (int i = 0; i < numStudents; i++) 
//    {
//        if (students[i].regNumber == regNumber) 
//        {
//            cout << "Student found!" << endl;
//            cout << "Registration Number: " << students[i].regNumber << endl;
//            cout << "Name: " << students[i].name << endl;
//            cout << "Program: " << students[i].program << endl;
//            cout << "CGPA: " << students[i].cgpa << endl;
//            cout << "Phone Number: " << students[i].phoneNumber << endl;
//            return;
//        }
//    }
//
//    cout << "Student with Registration Number " << regNumber << " not found!" << endl;
//}
//
//int main() 
//{
//    Student students[MAX_STUDENTS]; 
//    string filename = "data.csv";    
//
//  
//    int numStudents = readCSVFile(filename, students);
//
//    if (numStudents == 0) 
//    {
//        cout << "No data found in the file." << endl;
//        return 0;
//    }
//
//    
//    string regNumber;
//    cout << "Enter the Registration Number to search: ";
//    cin >> regNumber;
//
//    
//    searchStudentByRegNumber(students, numStudents, regNumber);
//
//    return 0;
//}

//#include <iostream>
//#include <fstream>
//#include <string>
//using namespace std;
//
//struct Student
//{
//    string regNumber;
//    string name;
//    string program;
//    float cgpa;
//    string phoneNumber;
//};
//
//
//void addStudentToFile(const string& filename, const Student& student)
//{
//    ofstream file(filename, ios::app);
//
//  
//    if (!file.is_open())
//    {
//        cerr << "Error opening the file!" << endl;
//        return;
//    }
//
// 
//    file << student.regNumber << ","
//        << student.name << ","
//        << student.program << ","
//        << student.cgpa << ","
//        << student.phoneNumber << endl;
//
//    file.close();
//    cout << "Student information added successfully!" << endl;
//}
//
//int main() 
//{
// 
//    Student newStudent;
//
//    
//    cout << "Enter the Registration Number: ";
//    cin >> newStudent.regNumber;
//
//    cin.ignore();  
//
//    cout << "Enter the Name: ";
//    getline(cin, newStudent.name);
//
//    cout << "Enter the Program (e.g., BBA, BSCS, SE): ";
//    getline(cin, newStudent.program);
//
//    cout << "Enter the CGPA: ";
//    cin >> newStudent.cgpa;
//
//    cin.ignore();  
//
//    cout << "Enter the Phone Number: ";
//    getline(cin, newStudent.phoneNumber);
//
//    
//    string filename = "data.csv"; 
//    addStudentToFile(filename, newStudent);
//
//    return 0;
//}

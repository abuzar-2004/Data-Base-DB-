//#include <iostream>
//#include <fstream>
//#include <string>
//using namespace std;
//
//const int MAX_STUDENTS = 100;  
//const int MAX_LENGTH = 100;    
//
//
//struct Student 
//{
//    string regNumber;
//    string name;
//    string program;
//    float cgpa;
//    string phoneNumber;
//};
//
//int readCSVFile(const string& filename, Student students[])
//{
//    ifstream file(filename);
//
//    if (!file.is_open()) 
//    {
//        cerr << "Error opening the file!" << endl;
//        return 0;
//    }
//
//    int count = 0;
//    string line;
//    while (getline(file, line) && count < MAX_STUDENTS) 
//    {
//        size_t startPos = 0, endPos = line.find(',');
//        students[count].regNumber = line.substr(startPos, endPos - startPos);
//
//        startPos = endPos + 1;
//        endPos = line.find(',', startPos);
//        students[count].name = line.substr(startPos, endPos - startPos);
//
//        startPos = endPos + 1;
//        endPos = line.find(',', startPos);
//        students[count].program = line.substr(startPos, endPos - startPos);
//
//        startPos = endPos + 1;
//        endPos = line.find(',', startPos);
//        students[count].cgpa = stof(line.substr(startPos, endPos - startPos));
//
//        startPos = endPos + 1;
//        students[count].phoneNumber = line.substr(startPos);
//
//        count++;
//    }
//
//    file.close();
//    return count;
//}
//
//bool deleteStudentRecord(Student students[], int& numStudents, const string& regNumber)
//{
//    bool found = false;
//    for (int i = 0; i < numStudents; i++) 
//    {
//        if (students[i].regNumber == regNumber) 
//        {
//            
//            for (int j = i; j < numStudents - 1; j++) 
//            {
//                students[j] = students[j + 1];
//            }
//            numStudents--;  
//            found = true;
//            break;
//        }
//    }
//    return found;
//}
//
//
//void writeCSVFile(const string& filename, Student students[], int numStudents) 
//{
//    ofstream file(filename);
//
//   
//    if (!file.is_open()) {
//        cerr << "Error opening the file!" << endl;
//        return;
//    }
//
//    
//    for (int i = 0; i < numStudents; i++) 
//    {
//        file << students[i].regNumber << ","
//            << students[i].name << ","
//            << students[i].program << ","
//            << students[i].cgpa << ","
//            << students[i].phoneNumber << endl;
//    }
//
//    file.close();
//}
//
//int main() 
//{
//    string filename = "data.csv";  
//    Student students[MAX_STUDENTS];  
//
//    
//    int numStudents = readCSVFile(filename, students);
//    if (numStudents == 0) {
//        cout << "No data found in the file." << endl;
//        return 0;
//    }
//
//    
//    string regNumber;
//    cout << "Enter the Registration Number of the student to delete: ";
//    cin >> regNumber;
//
//    
//    bool deleted = deleteStudentRecord(students, numStudents, regNumber);
//    if (deleted) 
//    {
//      
//        writeCSVFile(filename, students, numStudents);
//        cout << "Student record deleted successfully!" << endl;
//    }
//    else {
//        cout << "Student with Registration Number " << regNumber << " not found!" << endl;
//    }
//
//    return 0;
//}
